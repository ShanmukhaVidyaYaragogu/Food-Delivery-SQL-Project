# Project Explanation and Interview Notes

## Project summary
I designed a fictional food-delivery analytics database in PostgreSQL. The goal is to answer business questions about delivered food sales, restaurant performance, menu-item demand, repeat orders, and order status.

## Table design
- `customers`: one row per customer.
- `restaurants`: one row per restaurant.
- `menu_items`: menu items offered by restaurants.
- `orders`: one row per order, linked to a customer and restaurant.
- `order_items`: one row per item line in an order, with quantity and recorded sale price.

## Relationships
- One customer can place many orders.
- One restaurant can receive many orders and offer many menu items.
- One order can contain many order-item rows.
- Each order-item row refers to one menu item.

## Why a separate order_items table?
An order can contain multiple dishes. Separate line-item rows let us calculate quantities and item-level revenue without storing a comma-separated list or repeating dish columns.

## Metric definitions
- **Food revenue:** `SUM(quantity * unit_price)` for delivered orders.
- **Average food order value:** average of each delivered order's food subtotal, not average dish price.
- **Units sold:** sum of quantities in delivered orders.
- **Cancellation rate:** cancelled orders divided by all orders in the selected period; state the denominator.
- Delivery fees are excluded from food revenue. Profit is not calculated because costs, discounts, taxes, and refunds are not modeled.

## Interview pitch (adapt to what you personally ran)
“I created a Food Delivery Sales and Customer Analytics project using PostgreSQL. I designed five related tables for customers, restaurants, menu items, orders, and order items, using primary keys, foreign keys, and constraints. I wrote SQL queries using joins, aggregate functions, GROUP BY, HAVING, CTEs, CASE expressions, and window functions. The queries analyze delivered food revenue, restaurant rankings, best-selling items, average order value, repeat customers, and order status. I also added data-quality checks. The dataset is fictional, and next steps could include delivery times, payments, refunds, discounts, and query-performance testing.”

## Interview questions
**Why primary keys?** They uniquely identify rows.

**Why foreign keys?** They help preserve relationships and prevent references to missing parent records.

**WHERE vs HAVING?** WHERE filters rows before grouping; HAVING filters groups after aggregate calculations.

**INNER JOIN vs LEFT JOIN?** INNER JOIN returns matches only. LEFT JOIN preserves all left-side rows and uses NULL where no right-side match exists.

**Why use a CTE?** It names an intermediate query result and makes multi-step logic easier to read.

**What does DENSE_RANK do?** Rows with equal values share a rank, and the next rank has no gap.

**Limitations?** The data is fictional and small. It does not model payment, refund, discount, tax, delivery duration, ratings, or cost data. Performance has not been benchmarked.

## Future work
1. Add pickup and delivery-completion timestamps.
2. Add payment, refund, discount, and tax tables.
3. Analyze delivery duration and cancellation trends.
4. Evaluate indexes using query plans on larger data.
5. Connect validated outputs to a dashboard.
