# Entity Relationships (Text ERD)

```text
customers (1) --------< orders >-------- (1) restaurants
                           |
                           | (1)
                           v
                      order_items >-------- (1) menu_items
                                                ^
                                                |
restaurants (1) -------------------------------<|
             one restaurant offers many menu items
```

Foreign-key relationships:
- `customers.customer_id` -> `orders.customer_id`
- `restaurants.restaurant_id` -> `orders.restaurant_id`
- `restaurants.restaurant_id` -> `menu_items.restaurant_id`
- `orders.order_id` -> `order_items.order_id`
- `menu_items.item_id` -> `order_items.item_id`

`orders` connects a customer to a restaurant for a purchase. `order_items` records individual dishes and quantities in that order.
